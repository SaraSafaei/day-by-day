$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
try {
    # Prefer Android Studio's bundled Java; Gradle 8.9 supports JDK 17 and 21.
    $javaCandidates = @($env:JAVA_HOME, "$env:ProgramFiles\Android\Android Studio\jbr", "$env:LOCALAPPDATA\Programs\Android Studio\jbr")
    $javaRoot = $javaCandidates | Where-Object { $_ -and (Test-Path (Join-Path $_ 'bin\java.exe')) } | Select-Object -First 1
    if (-not $javaRoot) { throw 'Java not found. Install Android Studio with its default options, then run this file again.' }
    $env:JAVA_HOME = $javaRoot
    $sdkCandidates = @($env:ANDROID_HOME, $env:ANDROID_SDK_ROOT, "$env:LOCALAPPDATA\Android\Sdk")
    $sdkRoot = $sdkCandidates | Where-Object { $_ -and (Test-Path (Join-Path $_ 'platforms\android-35\android.jar')) } | Select-Object -First 1
    if (-not $sdkRoot) { throw 'Android SDK 35 not found. In Android Studio > SDK Manager install Android 15 (API 35), then run this file again.' }
    if (-not (Test-Path (Join-Path $sdkRoot 'build-tools\34.0.0'))) { throw 'Install Android SDK Build-Tools 34.0.0 in SDK Manager > SDK Tools > Show Package Details.' }
    $sdkPath = $sdkRoot.Replace('\', '/').Replace(':', '\:')
    [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'local.properties'), "sdk.dir=$sdkPath`n", (New-Object Text.UTF8Encoding($false)))
    $toolsDir = Join-Path $PSScriptRoot '.tools'
    New-Item -ItemType Directory -Force $toolsDir | Out-Null
    $gradleExe = Join-Path $toolsDir 'gradle-8.9\bin\gradle.bat'
    if (-not (Test-Path $gradleExe)) {
        Write-Host 'Downloading Gradle 8.9. Internet access is required for the first build.'
        $archive = Join-Path $toolsDir 'gradle-8.9-bin.zip'
        $checksumFile = "$archive.sha256"
        Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile $archive -UseBasicParsing
        Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-8.9-bin.zip.sha256' -OutFile $checksumFile -UseBasicParsing
        $expected = (Get-Content $checksumFile -Raw).Trim().Split(' ')[0]
        $actual = (Get-FileHash $archive -Algorithm SHA256).Hash
        if ($actual -ne $expected) { Remove-Item $archive -Force; throw 'Gradle download checksum mismatch. Run again to download a clean copy.' }
        Expand-Archive $archive -DestinationPath $toolsDir -Force
        Remove-Item $archive, $checksumFile -Force
    }
    # Generate the standard Gradle wrapper for subsequent Android Studio use.
    & $gradleExe --no-daemon wrapper --gradle-version 8.9 --distribution-type bin
    if ($LASTEXITCODE -ne 0) { throw 'Gradle setup failed. See the error above. Check access to Google Maven and Maven Central.' }
    & $gradleExe --no-daemon :app:assembleDebug :app:lintDebug
    if ($LASTEXITCODE -ne 0) { throw 'Android build failed. See the error above.' }
    New-Item -ItemType Directory -Force 'output' | Out-Null
    Copy-Item 'app\build\outputs\apk\debug\app-debug.apk' 'output\Day-by-Day.apk' -Force
    Write-Host "APK ready: $PSScriptRoot\output\Day-by-Day.apk" -ForegroundColor Green
    Start-Process explorer.exe (Join-Path $PSScriptRoot 'output')
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
