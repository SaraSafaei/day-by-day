# Verification status

Passed against the packaged web source (2026-10-21):
- Model checks: Persian calendar, schedules, streaks, archive/restore, backup schema validation.
- Simulated DOM/Node VM checks: all four views in Persian and English, retained data, Gregorian vs Persian calendar, remembered language and navigation.
- Android JavaScript export handoff: JSON payload and filename in both languages; success/failure UI callback. The Android interface was mocked for this check.
- Backup import: valid replacement, malformed JSON leaves stored data intact, cancelled replacement leaves data intact.
- XML parsing and manifest check (no INTERNET permission).

Run the source checks with Node.js from the tests folder:
    node test-model.mjs
    node test-language.mjs

Not verified here:
- Gradle compilation, Android lint, APK signing or installation.
- Real Android WebView, SAF file picker, native Java lifecycle, keyboard/insets and back behavior.
- Browser visual QA: Playwright is available but its browser executable is absent.

Android SDK and Gradle are absent in the build environment. Attempts to access the official Android SDK and Gradle download endpoints timed out. No APK was generated. Build-APK.cmd builds and runs Android lint on a Windows machine with the prerequisites in README-FA.md.
