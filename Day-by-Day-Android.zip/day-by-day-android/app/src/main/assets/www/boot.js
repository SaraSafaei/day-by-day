const key='day-by-day-language';
const locale=document.documentElement.lang;
let preferred=null;
try{preferred=localStorage.getItem(key)}catch{}
if((preferred==='en'||preferred==='fa')&&locale!==preferred){
 location.replace((preferred==='en'?'index-en.html':'index.html')+location.hash);
}else{
 document.querySelector('#language-select').addEventListener('change',e=>{
  const next=e.target.value;
  try{localStorage.setItem(key,next)}catch{}
  location.assign((next==='en'?'index-en.html':'index.html')+location.hash);
 });
 await import(locale==='en'?'./app-en.js':'./app.js');
}
