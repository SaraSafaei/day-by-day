export {today,keyDate,dateOf,shift,scheduled,stats,streak,validateBackup} from './model.js';
import {dateOf,keyDate} from './model.js';
export function monthDays(k){
 const d=dateOf(k),y=d.getFullYear(),m=d.getMonth();
 const count=new Date(y,m+1,0,12).getDate();
 return Array.from({length:count},(_,i)=>keyDate(new Date(y,m,i+1,12)));
}
