package com.sarasafaei.daybyday;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowInsets;
import android.webkit.*;
import android.widget.FrameLayout;
import androidx.webkit.WebViewAssetLoader;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/assets/www/index.html";
    private static final int OPEN = 10, SAVE = 11;
    private WebView web;
    private ValueCallback<Uri[]> chooser;
    private boolean exportPending;
    private final java.util.concurrent.ExecutorService io = java.util.concurrent.Executors.newSingleThreadExecutor();

    private boolean local(Uri uri) {
        return "https".equals(uri.getScheme()) && HOST.equals(uri.getHost())
            && uri.getPort() == -1 && uri.getPath() != null && uri.getPath().startsWith("/assets/www/");
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        exportPending = state != null && state.getBoolean("exportPending");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xfffaf8fc);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                Insets safe = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                v.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return WindowInsets.CONSUMED;
            });
            root.requestApplyInsets();
        }
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true); // SAF-selected backup is read by the file input.
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        web.setBackgroundColor(0xfffaf8fc);
        WebView.setWebContentsDebuggingEnabled(false);
        CookieManager.getInstance().setAcceptCookie(false);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                if (local(req.getUrl())) {
                    WebResourceResponse response = loader.shouldInterceptRequest(req.getUrl());
                    if (response != null) return response;
                }
                return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null,
                    new ByteArrayInputStream(new byte[0]));
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                return !local(req.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (chooser != null) chooser.onReceiveValue(null);
                chooser = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("*/*").putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
                try { startActivityForResult(intent, OPEN); }
                catch (RuntimeException ex) { chooser.onReceiveValue(null); chooser = null; report(false); }
                return true;
            }
            @Override public boolean onJsConfirm(WebView v, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this).setMessage(message)
                    .setPositiveButton(android.R.string.ok, (d,w) -> result.confirm())
                    .setNegativeButton(android.R.string.cancel, (d,w) -> result.cancel())
                    .setOnCancelListener(d -> result.cancel()).show();
                return true;
            }
        });
        web.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        String restored = state == null ? null : state.getString("page");
        web.loadUrl(restored != null && local(Uri.parse(restored)) ? restored : START);
    }

    public final class BackupBridge {
        @JavascriptInterface public void saveBackup(String json, String filename) {
            if (json == null || json.length() > 10 * 1024 * 1024) { runOnUiThread(() -> report(false)); return; }
            runOnUiThread(() -> {
                if (exportPending) return;
                exportPending = true;
                io.execute(() -> {
                    try {
                        new JSONObject(json);
                        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
                        if (bytes.length > 10 * 1024 * 1024) throw new IOException("Backup too large");
                        try (FileOutputStream out = new FileOutputStream(new File(getCacheDir(), "pending-backup.json"))) { out.write(bytes); }
                        runOnUiThread(() -> {
                            try {
                                String name = filename != null && filename.matches("rooz-backup-[0-9-]+\\.json") ? filename : "day-by-day-backup.json";
                                startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT)
                                    .addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
                                    .putExtra(Intent.EXTRA_TITLE, name), SAVE);
                            } catch (RuntimeException ex) { exportPending = false; report(false); }
                        });
                    } catch (Exception ex) { runOnUiThread(() -> { exportPending = false; report(false); }); }
                });
            });
        }
    }
    private void report(boolean ok) {
        if (!isFinishing() && !isDestroyed()) web.evaluateJavascript("window.androidBackupResult && window.androidBackupResult(" + ok + ")", null);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == OPEN && chooser != null) {
            Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
            chooser.onReceiveValue(uri != null && "content".equals(uri.getScheme()) ? new Uri[]{uri} : null);
            chooser = null;
        } else if (request == SAVE) {
            if (result != RESULT_OK || data == null || data.getData() == null) {
                exportPending = false;
                new File(getCacheDir(), "pending-backup.json").delete();
                return;
            }
            Uri destination = data.getData();
            io.execute(() -> {
                boolean ok = false;
                File pending = new File(getCacheDir(), "pending-backup.json");
                try (InputStream in = new FileInputStream(pending);
                     OutputStream out = getContentResolver().openOutputStream(destination, "wt")) {
                    if (out == null) throw new IOException("Cannot save");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                    out.flush(); ok = true;
                } catch (IOException ex) { /* Report to the UI below. */ }
                finally { pending.delete(); }
                boolean success = ok;
                runOnUiThread(() -> { exportPending = false; report(success); });
            });
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("(function(){var d=document.querySelector('dialog[open]');if(d){d.close();return true;}var b=document.querySelector('nav button[data-view=\"today\"]');if(b&&!b.classList.contains('active')){b.click();return true;}return false;})()", result -> {
            if (!"true".equals(result)) new AlertDialog.Builder(this).setMessage("بستن برنامه؟ / Close app?")
                .setPositiveButton(android.R.string.ok, (d,w) -> finish())
                .setNegativeButton(android.R.string.cancel, null).show();
        });
    }
    @Override protected void onSaveInstanceState(Bundle state) {
        super.onSaveInstanceState(state);
        state.putBoolean("exportPending", exportPending);
        state.putString("page", web.getUrl());
    }
    @Override protected void onDestroy() {
        if (chooser != null) { chooser.onReceiveValue(null); chooser = null; }
        web.removeJavascriptInterface("AndroidBackup");
        web.destroy(); io.shutdown(); super.onDestroy();
    }
}
