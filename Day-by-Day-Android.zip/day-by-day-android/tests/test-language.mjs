import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import * as faModel from '../app/src/main/assets/www/model.js';
import * as enModel from '../app/src/main/assets/www/model-en.js';
const now=faModel.today();
const sample={version:1,habits:[{id:'a',name:'مطالعه شخصی',desc:'My own words',color:0,created:now,versions:[{from:now,days:[0,1,2,3,4,5,6],archived:false}]}],logs:{[now]:{a:true}},notes:{[now]:{text:'یادداشت من',mood:4}}};
for(const language of ['fa','en']){
 const nodes=new Map(),events={};
 const node=s=>{if(!nodes.has(s))nodes.set(s,{innerHTML:'',textContent:'',value:'',dataset:{},classList:{toggle(){},add(){},remove(){}},addEventListener(t,f){this[t]=f},showModal(){},close(){},focus(){}});return nodes.get(s)};
 const storage=new Map([['rooz-habits-v1',JSON.stringify(sample)]]);
 const context={...language==='fa'?faModel:enModel,Intl,Date,console,crypto:globalThis.crypto,setTimeout:()=>0,clearTimeout(){},location:{hash:''},localStorage:{getItem:k=>storage.get(k),setItem:(k,v)=>storage.set(k,v)},document:{querySelector:node,querySelectorAll:()=>[],addEventListener:(t,f)=>events[t]=f},window:{addEventListener(){},scrollTo(){}}};
 vm.createContext(context);
 vm.runInContext(fs.readFileSync(`../app/src/main/assets/www/app${language==='en'?'-en':''}.js`,'utf8').replace(/^import .*;$/m,''),context);
 for(const view of ['today','progress','journal','settings']){
  events.click({target:{closest:()=>({dataset:{view},hasAttribute:()=>false})}});
  assert.ok(node('#content').innerHTML.length>100);
  assert.ok(node('#content').innerHTML.includes(view==='journal'?'یادداشت من':'مطالعه شخصی'));
 }
 assert.equal(storage.get('rooz-habits-v1'),JSON.stringify(sample),'switching views must not overwrite data');
 let backup;
 context.document.documentElement={lang:language};
 context.window.AndroidBackup={saveBackup:(json,name)=>{backup={json,name}}};
 events.click({target:{closest:()=>({id:'export',dataset:{},hasAttribute:()=>false})}});
 assert.deepEqual(JSON.parse(backup.json),sample);
 assert.match(backup.name,/^rooz-backup-.*\.json$/);
 context.window.androidBackupResult(true);
 assert.match(node('#toast').textContent,language==='fa'?/ذخیره شد/:/Backup saved/);
 context.window.androidBackupResult(false);
 assert.match(node('#toast').textContent,language==='fa'?/انجام نشد/:/Could not save/);
 const replacement=structuredClone(sample);replacement.habits[0].name='Restored';
 context.confirm=()=>true;
 const input={files:[{size:100,text:async()=>JSON.stringify(replacement)}],value:'backup.json'};
 await node('#import-file').onchange({target:input});
 assert.equal(JSON.parse(storage.get('rooz-habits-v1')).habits[0].name,'Restored');
 const before=storage.get('rooz-habits-v1');
 await node('#import-file').onchange({target:{files:[{size:100,text:async()=>'{bad'}],value:'bad.json'}});
 assert.equal(storage.get('rooz-habits-v1'),before);
 context.confirm=()=>false;
 await node('#import-file').onchange({target:{files:[{size:100,text:async()=>JSON.stringify(sample)}],value:'cancel.json'}});
 assert.equal(storage.get('rooz-habits-v1'),before);

}
assert.equal(enModel.monthDays('2026-10-18').length,31);
assert.equal(enModel.monthDays('2026-10-18')[0],'2026-10-01');
const boot=fs.readFileSync('../app/src/main/assets/www/boot.js','utf8').replace("await import(locale==='en'?'./app-en.js':'./app.js');",'loaded=true;');
for(const locale of ['fa','en'])for(const preferred of ['fa','en',null]){
 let redirect,handler,saved;
 const ctx={loaded:false,document:{documentElement:{lang:locale},querySelector:()=>({addEventListener:(t,f)=>handler=f})},localStorage:{getItem:()=>preferred,setItem:(k,v)=>saved=v},location:{hash:'#journal',replace:p=>redirect=p,assign:p=>redirect=p}};
 vm.runInNewContext(boot,ctx);
 if(preferred&&preferred!==locale)assert.equal(redirect,`${preferred==='en'?'index-en.html':'index.html'}#journal`);
 else {assert.ok(ctx.loaded);const next=locale==='fa'?'en':'fa';handler({target:{value:next}});assert.equal(saved,next);assert.equal(redirect,`${next==='en'?'index-en.html':'index.html'}#journal`)}
}
console.log('PASS: native export handoff and success/failure feedback, valid/invalid/cancelled import; both languages render all four views, preserve personal data, use correct calendar, and remember language/navigation.');
